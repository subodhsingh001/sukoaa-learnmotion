import SevenInteractiveLesson from "@/components/lesson/SevenInteractiveLesson";
export default function Page(){return <SevenInteractiveLesson kind="photosynthesis"/>}
